#!/bin/bash
echo "LiraElite Tek Tikla APK Fabrikasi"
python3 APK_AL.py
