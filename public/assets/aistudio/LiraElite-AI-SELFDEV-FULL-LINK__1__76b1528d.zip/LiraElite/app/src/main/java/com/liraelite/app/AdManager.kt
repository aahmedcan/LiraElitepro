
package com.liraelite.app
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
class AdManager(private val ctx: Context) {
    private var rewardedAd: RewardedAd? = null
    private val functions = FirebaseFunctions.getInstance()
    fun loadAd() {
        val req = AdRequest.Builder().build()
        RewardedAd.load(ctx, "ca-app-pub-3940256099942544/5224354917", req, object: RewardedAdLoadCallback(){
            override fun onAdLoaded(ad: RewardedAd) { rewardedAd = ad }
        })
    }
    suspend fun verifyReward(uid: String): Boolean {
        return try {
            val data = hashMapOf("uid" to uid, "source" to "admob_rewarded")
            val res = functions.getHttpsCallable("verifyAdReward").call(data).await()
            val ok = (res.data as Map<*, *> )["success"] as Boolean
            ok
        } catch (e: Exception) { false }
    }
}
