#!/bin/bash
echo "LiraElite Tam Otomatik Kurulum Basliyor..."
echo "GitHub repo URL'sini gir (ornek: https://github.com/kullanici/LiraElite.git):"
read REPO
git init
git add .
git branch -M main
git remote add origin $REPO
git commit -m "LiraElite tam otomatik sistem ilk kurulum"
git push -u origin main
echo "Bitti! GitHub Actions APK'yi derliyor, 3 dk sonra Actions sekmesinden indirebilirsin."
