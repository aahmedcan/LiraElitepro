
package com.liraelite.app.ai

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import kotlinx.coroutines.tasks.await

// KENDI KENDINE GELISEN UYGULAMA MANTIĞI
object SelfDeveloper {
    private val remoteConfig = FirebaseRemoteConfig.getInstance()
    private val db = FirebaseFirestore.getInstance()

    data class Evolution(
        val newReward: Double,
        val newUiColor: String,
        val newFeatures: List<String>,
        val apkUrl: String,
        val versionName: String
    )

    // Uygulama acilinca kendini gelistir - kod degistirmeden
    suspend fun evolve(): Evolution? {
        return try {
            remoteConfig.fetchAndActivate().await()
            val reward = remoteConfig.getDouble("ad_reward")
            val color = remoteConfig.getString("ui_theme_color")
            val features = remoteConfig.getString("enabled_features").split(",")
            
            // Firestore'dan en son APK linkini al - BU SENIN ISTEDIGIN DIREKT LINK SISTEMI
            val appVersion = db.collection("config").document("appVersion").get().await()
            val apkUrl = appVersion.getString("apkUrl") ?: "https://github.com/liraelite/LiraElite/releases/latest/download/app-debug.apk"
            val version = appVersion.getString("versionName") ?: "1.1-AI"

            Evolution(
                newReward = if (reward > 0) reward else 0.50,
                newUiColor = if (color.isNotEmpty()) color else "#D4AF37",
                newFeatures = features,
                apkUrl = apkUrl,
                versionName = version
            )
        } catch (e: Exception) { null }
    }

    // BIZE OZEL: APK linkini Firestore'a yaz - sen link verebil diye
    suspend fun publishApkLink(publicUrl: String, version: String, changelog: String) {
        db.collection("config").document("appVersion").set(mapOf(
            "apkUrl" to publicUrl,
            "versionName" to version,
            "versionCode" to System.currentTimeMillis(),
            "changelog" to changelog,
            "updatedAt" to System.currentTimeMillis(),
            "isAiGenerated" to true
        )).await()
    }
}
