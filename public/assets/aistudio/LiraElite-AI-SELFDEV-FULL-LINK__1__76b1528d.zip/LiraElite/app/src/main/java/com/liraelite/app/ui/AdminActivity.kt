
package com.liraelite.app.ui
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.liraelite.app.Config
class AdminActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val email = FirebaseAuth.getInstance().currentUser?.email
        if (email?.lowercase() != Config.ADMIN_EMAIL.lowercase()){
            finish()
            return
        }
        // Admin console UI burada
        // Yapay zeka komut paneli: Firestore /admin/commands
    }
}
