
import os, subprocess, pathlib, webbrowser, time
print("=== LiraElite Tek Tikla APK Fabrikasi ===")
print("Hersey otomatik, sen sadece bekle...")
base = pathlib.Path(__file__).parent

# gradlew var mi?
gradlew = base / "gradlew"
if not gradlew.exists():
    print("Gradle wrapper olusturuluyor...")
    os.system("gradle wrapper --gradle-version 8.4")

print("APK derleniyor, bu 2-3 dk surebilir...")
# debug apk
result = subprocess.run(["./gradlew" if os.name != 'nt' else "gradlew.bat", "assembleDebug"], cwd=base)
if result.returncode == 0:
    apk = base / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk"
    if apk.exists():
        print(f"\n✓ APK HAZIR: {apk}")
        print(f"Boyut: {apk.stat().st_size / 1024 / 1024:.2f} MB")
        print(f"Indırme baglantisi: file://{apk.resolve()}")
        # tarayicida ac
        try:
            webbrowser.open(f"file://{apk.parent}")
        except:
            pass
        print("\nTelefonuna at ve kur!")
    else:
        print("APK bulunamadi, build klasorunu kontrol et")
else:
    print("Derleme hatasi, Android Studio'da acmayi dene")
