
package com.liraelite.app.ui
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.liraelite.app.AuthManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
class LoginActivity: AppCompatActivity() {
    private val authMgr = AuthManager()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(com.liraelite.app.R.string.default_web_client_id))
            .requestEmail().build()
        val client = GoogleSignIn.getClient(this, gso)
        startActivityForResult(client.signInIntent, 1001)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode==1001){
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.result
            CoroutineScope(Dispatchers.Main).launch {
                val profile = authMgr.handleGoogleLogin(account.idToken!!)
                if (profile.isAdmin) startActivity(Intent(this@LoginActivity, AdminActivity::class.java))
                else startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            }
        }
    }
}
