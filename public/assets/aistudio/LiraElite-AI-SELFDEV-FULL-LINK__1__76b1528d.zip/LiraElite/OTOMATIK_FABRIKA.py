
import http.server, socketserver, pathlib, threading, subprocess, os, time

PORT = 8080
BASE = pathlib.Path(__file__).parent
APK_DIR = BASE / "app" / "build" / "outputs" / "apk" / "debug"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)
    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            apk_path = APK_DIR / "app-debug.apk"
            if apk_path.exists():
                size = apk_path.stat().st_size / 1024 / 1024
                html = f'''
                <html><head><meta charset="utf-8"><title>LiraElite APK Fabrikasi</title>
                <style>body{{background:#0A1931;color:#D4AF37;font-family:sans-serif;text-align:center;padding:50px}}a{{background:#D4AF37;color:#0A1931;padding:20px 40px;border-radius:12px;text-decoration:none;font-weight:bold;font-size:20px;display:inline-block;margin:20px}}</style>
                </head><body>
                <h1>LiraElite APK Hazir!</h1>
                <p>Boyut: {size:.2f} MB</p>
                <a href="/app/build/outputs/apk/debug/app-debug.apk" download>📲 APK INDIR - Telefona Kur</a>
                <p>Her gelistirmede bu sayfa otomatik yenilenir</p>
                </body></html>
                '''
            else:
                html = '''
                <html><head><meta charset="utf-8"><title>LiraElite Derleniyor</title>
                <meta http-equiv="refresh" content="5">
                <style>body{background:#0A1931;color:#D4AF37;font-family:sans-serif;text-align:center;padding:50px}</style>
                </head><body><h1>APK Derleniyor... 2-3 dk</h1><p>Sayfa otomatik yenilenecek</p></body></html>
                '''
            self.wfile.write(html.encode('utf-8'))
        else:
            return super().do_GET()

def build_loop():
    print("Otomatik derleme basladi...")
    while True:
        try:
            subprocess.run(["./gradlew", "assembleDebug"], cwd=BASE)
        except:
            pass
        time.sleep(300) # 5 dk'da bir yeniden derle

print(f"Fabrika calisiyor: http://localhost:{PORT}")
print("Bu linki ac, APK indirme baglantisi orada olacak")
print("Her degisiklikte otomatik yeniden derlenecek")

# ilk derlemeyi baslat
threading.Thread(target=build_loop, daemon=True).start()

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    httpd.serve_forever()
