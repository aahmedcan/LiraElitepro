
package com.liraelite.app.ui
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.liraelite.app.AdManager
import com.liraelite.app.Config
import com.liraelite.app.UpdateManager
import com.liraelite.app.WalletManager
import com.liraelite.app.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
class MainActivity: AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adMgr: AdManager
    private lateinit var updateMgr: UpdateManager
    private val wallet = WalletManager()
    private val db = FirebaseFirestore.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adMgr = AdManager(this)
        updateMgr = UpdateManager(this)
        adMgr.loadAd()
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        db.collection("users").document(uid).addSnapshotListener{ snap, _ ->
            val bal = snap?.getDouble("balance") ?: 0.0
            binding.tvBalance.text = "Bakiye: %.2f TL".format(bal)
        }
        binding.btnWatchAd.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                val ok = adMgr.verifyReward(uid)
                if (ok) Toast.makeText(this@MainActivity, "0.50 TL eklendi!", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this@MainActivity, "Dogrulama basarisiz / limit doldu", Toast.LENGTH_SHORT).show()
                adMgr.loadAd()
            }
        }
        binding.btnDaily.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                Toast.makeText(this@MainActivity, "Gunluk bonus kontrol edildi", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnWithdraw.setOnClickListener {
        }
        // OTOMATIK GUNCELLEME KONTROLU - ANA HAFIZAYA ENTEGRE
        CoroutineScope(Dispatchers.Main).launch {
            val update = updateMgr.checkUpdate()
            if (update != null) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Yeni Surum: ${update.versionName}")
                    .setMessage("${update.changelog}\n\nSimdi indirip kurmak ister misin? Tek tikla APK indirme.")
                    .setPositiveButton("Indir ve Kur"){ _, _ ->
                        updateMgr.downloadAndInstall(update.apkUrl)
                        Toast.makeText(this@MainActivity, "Indiriliyor... Bildirimden takip et", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Sonra"){ d, _ -> d.dismiss() }
                    .show()
            }
        }
    }
}
