
package com.liraelite.app
object Config {
    const val ADMIN_EMAIL = "aahmedcan@gmail.com"
    const val REWARD_PER_AD_TL = 0.50
    const val DAILY_LOGIN_BONUS = 1.0
    const val MAX_ADS_PER_DAY = 20
    const val MIN_WITHDRAW_TL = 50.0
    const val PLATFORM_CUT = 0.50
    const val ENABLE_REAL_BANK_HOLD = false
}
