
const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();
exports.verifyAdReward = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated','Giris gerekli');
  const uid = context.auth.uid;
  const userRef = db.collection('users').doc(uid);
  const snap = await userRef.get();
  const todayCount = snap.get('adsWatchedToday')||0;
  if (todayCount >= 20) throw new functions.https.HttpsError('resource-exhausted','Gunluk limit');
  await userRef.update({
    balance: admin.firestore.FieldValue.increment(0.50),
    totalEarned: admin.firestore.FieldValue.increment(0.50),
    adsWatchedToday: admin.firestore.FieldValue.increment(1),
    lastAdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  await db.collection('revenue').add({uid, amount: 0.50, platformCut: 0.50, at: admin.firestore.FieldValue.serverTimestamp()});
  return {success:true};
});
exports.createWithdrawRequest = functions.https.onCall(async (data, context)=>{
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated','Giris gerekli');
  const {amount, iban} = data;
  if (amount < 50) throw new functions.https.HttpsError('invalid-argument','Min 50 TL');
  const uid = context.auth.uid;
  const userRef = db.collection('users').doc(uid);
  const snap = await userRef.get();
  const balance = snap.get('balance')||0;
  if (balance < amount) throw new functions.https.HttpsError('failed-precondition','Yetersiz bakiye');
  await userRef.update({balance: admin.firestore.FieldValue.increment(-amount)});
  const req = await db.collection('withdrawals').add({uid, amount, iban, status:'pending', createdAt: admin.firestore.FieldValue.serverTimestamp()});
  return {requestId: req.id};
});
exports.dailyReset = functions.pubsub.schedule('every day 00:00').timeZone('Europe/Istanbul').onRun(async ()=>{
  const users = await db.collection('users').get();
  const batch = db.batch();
  users.forEach(doc=> batch.update(doc.ref,{adsWatchedToday:0}));
  await batch.commit();
});

// APK Storage'a yuklenince otomatik Firestore guncelle - Tam otomatik dagitim
const {onObjectFinalized} = require("firebase-functions/v2/storage");
exports.onApkUpload = onObjectFinalized(async (event) => {
  const filePath = event.data.name; // apks/LiraElite-v1.apk gibi
  if (!filePath.startsWith("apks/") || !filePath.endsWith(".apk")) return;
  const bucket = event.data.bucket;
  const file = `https://storage.googleapis.com/${bucket}/${filePath}`;
  // versiyonu dosya adindan cek: LiraElite-v5.apk -> 5
  const match = filePath.match(/v(\d+)/);
  const versionCode = match ? parseInt(match[1]) : Date.now();
  await admin.firestore().collection("config").doc("appVersion").set({
    versionCode: versionCode,
    versionName: `1.0.${versionCode}`,
    apkUrl: file,
    changelog: `Otomatik build ${new Date().toLocaleString("tr-TR")} - Yeni ozellikler eklendi`,
    updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, {merge: true});
  console.log(`APK otomatik yayinlandi: ${file}`);
});
