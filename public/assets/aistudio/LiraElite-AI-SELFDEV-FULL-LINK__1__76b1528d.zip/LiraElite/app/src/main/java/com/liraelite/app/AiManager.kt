
package com.liraelite.app
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
class AiManager {
    private val functions = FirebaseFunctions.getInstance()
    suspend fun sendAdminCommand(command: String): String {
        val payload = mapOf("command" to command, "adminEmail" to Config.ADMIN_EMAIL)
        val res = functions.getHttpsCallable("aiAdminCommand").call(payload).await()
        return (res.data as Map<*,*> )["result"].toString()
    }
    suspend fun askSupport(question: String, uid: String): String {
        val payload = mapOf("question" to question, "uid" to uid)
        val res = functions.getHttpsCallable("aiSupport").call(payload).await()
        return (res.data as Map<*,*> )["answer"].toString()
    }
}
