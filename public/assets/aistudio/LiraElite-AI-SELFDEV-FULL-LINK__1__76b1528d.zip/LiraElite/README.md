
# LiraElite - Elit Kazanc Platformu
Bu klasor Android Studio'da acilmaya hazir profesyonel projedir.
Logo: app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
Detayli dokuman icin onceki mesaja bakin.
