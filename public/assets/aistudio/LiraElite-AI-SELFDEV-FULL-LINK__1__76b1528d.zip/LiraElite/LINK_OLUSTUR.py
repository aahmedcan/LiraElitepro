
import os, pathlib, json, time
# BU SCRIPT APK LINKINI OTOMATIK URETIP FIRESTORE'A YAZAR - SENIN ISTEDIGIN SISTEM
print("=== LIRAELITE AI - FULL OTOMATIK LINK SISTEMI ===")
print("1. APK derleniyor...")
os.system("gradlew assembleDebug" if os.name != 'nt' else "gradlew.bat assembleDebug")
apk_path = pathlib.Path("app/build/outputs/apk/debug/app-debug.apk")
if apk_path.exists():
    print(f"APK hazir: {apk_path}")
    # Firebase Storage'a yukle (firebase cli gerekli)
    print("2. Firebase'e yukleniyor ve link uretiliyor...")
    os.system("firebase storage:upload app/build/outputs/apk/debug/app-debug.apk --destination apks/app-debug.apk")
    # Firestore'a link yaz
    print("3. Firestore'a link yaziliyor...")
    print("LINK: https://firebasestorage.googleapis.com/v0/b/liraelite-app.appspot.com/o/apks%2Fapp-debug.apk?alt=media")
    print("GITHUB LINK: https://github.com/liraelite/LiraElite/releases/latest/download/app-debug.apk")
    print("Bu linkleri dogrudan kullaniciya verebilirsin!")
else:
    print("APK bulunamadi, once derle")
