
package com.liraelite.app.ui
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.liraelite.app.AdManager
import com.liraelite.app.UpdateManager
import com.liraelite.app.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity: AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adMgr: AdManager
    private lateinit var updateMgr: UpdateManager
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adMgr = AdManager(this)
        updateMgr = UpdateManager(this)
        adMgr.loadAd()

        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        db.collection("users").document(uid).addSnapshotListener{ snap, _ ->
            val bal = snap?.getDouble("balance") ?: 0.0
            binding.tvBalance.text = "Bakiye: %.2f TL".format(bal)
        }

        binding.btnWatchAd.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                val ok = adMgr.verifyReward(uid)
                if (ok) Toast.makeText(this@MainActivity, "0.50 TL eklendi!", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this@MainActivity, "Dogrulama basarisiz / limit doldu", Toast.LENGTH_SHORT).show()
                adMgr.loadAd()
            }
        }

        binding.btnDaily.setOnClickListener {
            Toast.makeText(this, "Gunluk bonus kontrol edildi", Toast.LENGTH_SHORT).show()
        }

        // APK KENDI KODLAMASINA ENTEGRE - ANA HAFIZADA
        binding.btnDownloadApk.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                Toast.makeText(this@MainActivity, "Son surum kontrol ediliyor...", Toast.LENGTH_SHORT).show()
                val update = updateMgr.checkUpdate()
                if (update != null) {
                    updateMgr.downloadAndInstall(update.apkUrl)
                    Toast.makeText(this@MainActivity, "APK indiriliyor: ${update.versionName}", Toast.LENGTH_LONG).show()
                } else {
                    // Eger Firestore'da yoksa direkt Storage'daki son APK'yi dene
                    db.collection("config").document("appVersion").get().addOnSuccessListener { snap ->
                        val url = snap.getString("apkUrl")
                        if (url != null) {
                            updateMgr.downloadAndInstall(url)
                        } else {
                            Toast.makeText(this@MainActivity, "Su an guncelsin! APK zaten en son surum.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        // OTOMATIK GUNCELLEME - UYGULAMA ACILINCA KENDI KENDINE KONTROL
        CoroutineScope(Dispatchers.Main).launch {
            val update = updateMgr.checkUpdate()
            if (update != null) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Yeni Surum: ${update.versionName}")
                    .setMessage("${update.changelog}\n\nUygulamanin kendi icinden tek tikla indirip kurmak ister misin?")
                    .setPositiveButton("İndir ve Kur"){ _, _ ->
                        updateMgr.downloadAndInstall(update.apkUrl)
                        Toast.makeText(this@MainActivity, "İndiriliyor... Bildirimden takip et", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Sonra"){ d, _ -> d.dismiss() }
                    .show()
            }
        }
    }
}
