#!/data/data/com.termux/files/usr/bin/sh
echo "=== LiraElite Termux Kurucu ==="
cd /sdcard/Download/LiraElite/LiraElite || cd /sdcard/Download/LiraElite
echo "Konum: $(pwd)"
echo "Gradle kuruluyor..."
pkg install gradle -y
chmod +x gradlew 2>/dev/null || true
chmod +x gradlew_termux 2>/dev/null || true
echo "Derleme başlıyor..."
if [ -f "gradlew" ]; then
  ./gradlew assembleDebug || gradle assembleDebug
else
  gradle assembleDebug
fi
echo "=== Bitti ==="
echo "APK: $(find app/build -name '*.apk' 2>/dev/null)"
