
# GitHub ile APK Linki Alma

1. GitHub'da yeni repo ac: LiraElite
2. Bu klasorun icindekileri yukle:
   git init
   git add .
   git commit -m "ilk"
   git branch -M main
   git remote add origin https://github.com/KULLANICIADIN/LiraElite.git
   git push -u origin main

3. GitHub'da Actions sekmesine git -> Build calisacak
4. Bitince Artifacts kisminda LiraElite-debug-apk cikacak -> tikla indir
5. Telefonuna kur

Gercek Firebase ile calismasi icin: app/google-services.json dosyasini Firebase Console'dan aldigin gercek dosya ile degistir ve tekrar pushla.

Admin hesabi: aahmedcan@gmail.com ile giris yapinca gizli yonetici paneli acilir.
