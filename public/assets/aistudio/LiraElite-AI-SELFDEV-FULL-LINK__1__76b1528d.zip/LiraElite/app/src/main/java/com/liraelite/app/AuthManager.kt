
package com.liraelite.app
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
class AuthManager {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    suspend fun handleGoogleLogin(idToken: String): UserProfile {
        val credential = com.google.firebase.auth.GoogleAuthProvider.getCredential(idToken, null)
        val result = auth.signInWithCredential(credential).await()
        val uid = result.user!!.uid
        val email = result.user!!.email ?: ""
        val isAdmin = email.lowercase() == Config.ADMIN_EMAIL.lowercase()
        val docRef = db.collection("users").document(uid)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val profile = hashMapOf(
                "email" to email,
                "role" to if (isAdmin) "admin" else "user",
                "balance" to 0.0,
                "totalEarned" to 0.0,
                "adsWatchedToday" to 0,
                "lastLogin" to com.google.firebase.Timestamp.now(),
                "streak" to 1,
                "createdAt" to com.google.firebase.Timestamp.now()
            )
            docRef.set(profile).await()
        } else {
            docRef.update(mapOf("lastLogin" to com.google.firebase.Timestamp.now())).await()
        }
        val finalSnap = docRef.get().await()
        return UserProfile(uid, email, finalSnap.getDouble("balance")?:0.0, isAdmin)
    }
}
data class UserProfile(val uid: String, val email: String, val balance: Double, val isAdmin: Boolean)
