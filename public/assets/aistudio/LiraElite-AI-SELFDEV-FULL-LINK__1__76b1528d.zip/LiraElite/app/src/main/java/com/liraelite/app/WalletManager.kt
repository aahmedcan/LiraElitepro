
package com.liraelite.app
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
class WalletManager {
    private val db = FirebaseFirestore.getInstance()
    private val functions = FirebaseFunctions.getInstance()
    suspend fun requestWithdraw(uid: String, amount: Double, iban: String): String {
        if (amount < Config.MIN_WITHDRAW_TL) throw IllegalArgumentException("Min cekim ${Config.MIN_WITHDRAW_TL} TL")
        val payload = mapOf("uid" to uid, "amount" to amount, "iban" to iban)
        val result = functions.getHttpsCallable("createWithdrawRequest").call(payload).await()
        return (result.data as Map<*, *> )["requestId"].toString()
    }
}
