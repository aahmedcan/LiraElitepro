
package com.liraelite.app

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class AppUpdate(val versionCode: Int, val versionName: String, val apkUrl: String, val changelog: String)

class UpdateManager(private val context: Context) {
    private val db = FirebaseFirestore.getInstance()

    // Firestore'da /config/appVersion dokumanini dinle
    suspend fun checkUpdate(): AppUpdate? {
        return try {
            val snap = db.collection("config").document("appVersion").get().await()
            if (!snap.exists()) return null
            val code = snap.getLong("versionCode")?.toInt() ?: 0
            val name = snap.getString("versionName") ?: "1.0"
            val url = snap.getString("apkUrl") ?: ""
            val log = snap.getString("changelog") ?: "Yeni surum"
            // kendi versiyonunu BuildConfig ile karsilastir
            val current = context.packageManager.getPackageInfo(context.packageName, 0).versionCode
            if (code > current && url.isNotEmpty()) {
                AppUpdate(code, name, url, log)
            } else null
        } catch (e: Exception) { null }
    }

    fun downloadAndInstall(url: String) {
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("LiraElite Guncelleme")
            .setDescription("Yeni surum indiriliyor...")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LiraElite-vLatest.apk")
            .setMimeType("application/vnd.android.package-archive")
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
    }

    // Indirilen APK'yi kur (Android 8+ icin REQUEST_INSTALL_PACKAGES izni gerekli)
    fun installApk(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(intent)
    }
}
