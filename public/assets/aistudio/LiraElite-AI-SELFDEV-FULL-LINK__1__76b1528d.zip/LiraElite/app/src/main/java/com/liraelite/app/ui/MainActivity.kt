
package com.liraelite.app.ui
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.liraelite.app.AdManager
import com.liraelite.app.UpdateManager
import com.liraelite.app.ai.LiraAiEngine
import com.liraelite.app.ai.SelfDeveloper
import com.liraelite.app.ai.ApkLinkProvider
import com.liraelite.app.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity: AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adMgr: AdManager
    private lateinit var updateMgr: UpdateManager
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        adMgr = AdManager(this)
        updateMgr = UpdateManager(this)
        adMgr.loadAd()

        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        db.collection("users").document(uid).addSnapshotListener{ snap, _ ->
            val bal = snap?.getDouble("balance") ?: 0.0
            binding.tvBalance.text = "Bakiye: %.2f TL".format(bal)
        }

        binding.btnWatchAd.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                val ok = adMgr.verifyReward(uid)
                if (ok) Toast.makeText(this@MainActivity, "0.50 TL eklendi!", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this@MainActivity, "Dogrulama basarisiz", Toast.LENGTH_SHORT).show()
                adMgr.loadAd()
                // AI kendi kendine analiz etsin
                LiraAiEngine.analyzeAndEvolve(uid)
            }
        }

        // AI ENTEGRE - KENDI KENDINE GELISEN BUTON
        binding.btnDownloadApk.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                val link = ApkLinkProvider.getLatestApkLink()
                Toast.makeText(this@MainActivity, "AI linki aldi: $link", Toast.LENGTH_SHORT).show()
                val update = updateMgr.checkUpdate()
                if (update != null) updateMgr.downloadAndInstall(update.apkUrl)
                else updateMgr.downloadAndInstall(link)
            }
        }

        // KENDI KENDINE GELISME - UYGULAMA ACILINCA
        CoroutineScope(Dispatchers.Main).launch {
            // 1. AI evrimi cek
            val evolution = SelfDeveloper.evolve()
            evolution?.let {
                binding.tvVersion.text = "v${it.versionName} - AI ile gelisti"
                // UI rengini AI belirlesin
            }
            // 2. Guncelleme kontrol
            val update = updateMgr.checkUpdate()
            if (update != null) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("AI Yeni Surum Buldu: ${update.versionName}")
                    .setMessage("${update.changelog}\n\nKendi kendine gelisen uygulama guncellensin mi?\nLink: ${update.apkUrl}")
                    .setPositiveButton("İndir ve Kur"){ _, _ -> updateMgr.downloadAndInstall(update.apkUrl) }
                    .setNegativeButton("Sonra"){ d, _ -> d.dismiss() }
                    .show()
            }
        }
    }
}
