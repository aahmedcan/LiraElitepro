
@echo off
echo LiraElite Tek Tikla APK Fabrikasi
python APK_AL.py
pause
