
package com.liraelite.app.ai

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

// FULL BENIM SANA LINK VEREBILMEM ICIN SISTEM - OTOMATIK APK DAGITIM
object ApkLinkProvider {
    private val db = FirebaseFirestore.getInstance()
    
    // 1. GitHub Releases linki - her zaman calisir
    const val GITHUB_LATEST_APK = "https://github.com/liraelite/LiraElite/releases/latest/download/app-debug.apk"
    
    // 2. Firebase Storage public link - otomatik yuklenir
    const val FIREBASE_APK_BASE = "https://firebasestorage.googleapis.com/v0/b/liraelite-app.appspot.com/o/apks%2Fapp-debug.apk?alt=media"

    // Uygulama icinden direkt link al
    suspend fun getLatestApkLink(): String {
        return try {
            val doc = db.collection("config").document("appVersion").get().await()
            doc.getString("apkUrl") ?: GITHUB_LATEST_APK
        } catch (e: Exception) {
            GITHUB_LATEST_APK
        }
    }

    // Kullaniciya ozel link uret - sen paylasabileceksin
    fun generateShareableLink(version: String): String {
        return "https://liraelite.app/download/$version - Direkt APK: $GITHUB_LATEST_APK"
    }
}
