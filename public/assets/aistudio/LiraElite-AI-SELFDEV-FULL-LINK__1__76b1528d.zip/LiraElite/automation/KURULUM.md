
# LIRAELITE TAM OTOMATIK SISTEM

Bu sistem her seyi otomatik yapar.

## 1 Dakikada Kurulum:

1. GitHub'da repo ac: LiraElite
2. Bu klasoru yukle (github klasorunu .github olarak yeniden adlandir!)
3. GitHub -> Settings -> Secrets and variables -> Actions -> New repository secret:
   - GOOGLE_SERVICES_JSON: Firebase'den indirdigin google-services.json dosyasinin icerigini kopyala yapistir
   - ADMOB_APP_ID: Gercek AdMob App ID
   - ADMOB_REWARD_ID: Gercek Rewarded Ad ID
   (Bunlar olmadan da calisir, demo modda APK uretir)

4. Bitti! Artik her push'ta:
   - APK otomatik derlenir
   - Artifact olarak yuklenir (indirme linki)
   - Release olarak yayinlanir (kalici indirme linki)
   - Her gun gece 00:00 otomatik yeniden derlenir

## APK Indirme Linki Nerede?

GitHub -> Actions -> En son build -> Asagida Artifacts -> LiraElite-APK-XXX.zip -> Indir
veya
GitHub -> Releases -> En son release -> Assets -> app-debug.apk -> Indir (bu link kalici ve telefonda acilir)

Bu link senin istedigin "APK indirme baglantisi"

## Tam Otomatik Ne Demek?

- Kod degisince otomatik derlenir
- Firebase config otomatik eklenir
- AdMob ID otomatik degisir
- APK otomatik imzalanir (keystore eklersen)
- Release otomatik olusur
- Telegram'a bildirim gider (bot eklersen)
- Her gun otomatik yeniden build alir

Sen hicbir sey yapmazsin, sistem kendi kendine APK linki uretir.
